"""
=============================================================================
SECTION 4 : Corrélation Thématiques × Montants BIP
Projet NLP ISE3 - ISSEA Yaoundé 2025-2026
=============================================================================
Usage :
    from section4_correlation_bip import run_correlation_bip
    resultats = run_correlation_bip(df_total, df_2024_classe, df_2025_classe)
=============================================================================
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from scipy.stats import spearmanr, pearsonr
import warnings
warnings.filterwarnings("ignore")


# ── Constantes ────────────────────────────────────────────────────────────────
PILIERS = [
    "Transformation structurelle",
    "Capital humain",
    "Gouvernance",
    "Développement régional"
]

COLORS_PILIERS = {
    "Transformation structurelle": "#2E86C1",
    "Capital humain":              "#E74C3C",
    "Gouvernance":                 "#27AE60",
    "Développement régional":      "#F39C12"
}


# ── Fonctions internes ────────────────────────────────────────────────────────

def _build_bilan(df_total: pd.DataFrame,
                 col_pilier: str,
                 col_texte:  str,
                 col_montant: str) -> pd.DataFrame:
    """
    Construit le tableau de bord par pilier :
    fréquence thématique, montant total, poids relatifs, écart.
    """
    bilan = df_total.groupby(col_pilier).agg(
        Frequence_Thematique=(col_texte,   "count"),
        Montant_Total        =(col_montant, "sum")
    ).reset_index()

    total_freq  = bilan["Frequence_Thematique"].sum()
    total_mont  = bilan["Montant_Total"].sum()

    bilan["Poids_Frequence_%"] = (bilan["Frequence_Thematique"] / total_freq * 100).round(2)
    bilan["Poids_Financier_%"] = (bilan["Montant_Total"]         / total_mont * 100).round(2)
    bilan["Montant_Milliards"] = (bilan["Montant_Total"]         / 1e9).round(3)
    bilan["Ecart_Poids_%"]     = (bilan["Poids_Financier_%"] - bilan["Poids_Frequence_%"]).round(2)
    bilan["Direction_Ecart"]   = bilan["Ecart_Poids_%"].apply(
        lambda x: "▲ Sur-financé"  if x > 0 else
                  "▼ Sous-financé" if x < 0 else "= Aligné"
    )
    return bilan.sort_values("Montant_Total", ascending=False).reset_index(drop=True)


def _build_bilan_annuel(df_total: pd.DataFrame,
                         col_pilier:  str,
                         col_texte:   str,
                         col_montant: str,
                         col_annee:   str) -> pd.DataFrame:
    """Tableau de bord par pilier ET par année."""
    bilan = df_total.groupby([col_annee, col_pilier]).agg(
        Frequence_Thematique=(col_texte,   "count"),
        Montant_Total        =(col_montant, "sum")
    ).reset_index()
    bilan["Montant_Milliards"] = (bilan["Montant_Total"] / 1e9).round(3)

    # Poids par année
    for annee in bilan[col_annee].unique():
        mask = bilan[col_annee] == annee
        tf   = bilan.loc[mask, "Frequence_Thematique"].sum()
        tm   = bilan.loc[mask, "Montant_Total"].sum()
        bilan.loc[mask, "Poids_Frequence_%"] = (
            bilan.loc[mask, "Frequence_Thematique"] / tf * 100).round(2)
        bilan.loc[mask, "Poids_Financier_%"] = (
            bilan.loc[mask, "Montant_Total"] / tm * 100).round(2)

    return bilan


def _calcul_correlations(bilan: pd.DataFrame) -> dict:
    """Pearson et Spearman entre poids fréquence et poids financier."""
    x = bilan["Poids_Frequence_%"].values
    y = bilan["Poids_Financier_%"].values

    r_p,  p_p  = pearsonr(x, y)
    r_s,  p_s  = spearmanr(x, y)

    if abs(r_p) >= 0.7:   force = "FORTE"
    elif abs(r_p) >= 0.4: force = "MODÉRÉE"
    else:                  force = "FAIBLE"

    direction = "positive" if r_p > 0 else "négative"
    sig       = "SIGNIFICATIF"     if p_p < 0.05 else "NON significatif"

    return {
        "pearson_r":  round(r_p, 4),
        "pearson_p":  round(p_p, 4),
        "pearson_r2": round(r_p**2 * 100, 2),
        "spearman_r": round(r_s, 4),
        "spearman_p": round(p_s, 4),
        "force":      force,
        "direction":  direction,
        "sig":        sig
    }


# ── Graphiques ────────────────────────────────────────────────────────────────

def _plot_regplot(bilan: pd.DataFrame,
                  corr:  dict,
                  col_pilier: str,
                  save_fig: bool,
                  path: str):
    """Nuage de points avec droite de régression — Discours vs Budget."""
    fig, ax = plt.subplots(figsize=(9, 6))

    for _, row in bilan.iterrows():
        pilier = row[col_pilier]
        color  = COLORS_PILIERS.get(pilier, "#7F8C8D")
        ax.scatter(row["Poids_Frequence_%"], row["Poids_Financier_%"],
                   s=350, color=color, edgecolors="black",
                   zorder=5, alpha=0.9)
        ax.annotate(pilier,
                    (row["Poids_Frequence_%"], row["Poids_Financier_%"]),
                    textcoords="offset points", xytext=(7, 5),
                    fontsize=9, fontweight="bold")

    # Droite de régression
    x = bilan["Poids_Frequence_%"].values
    y = bilan["Poids_Financier_%"].values
    m, b   = np.polyfit(x, y, 1)
    xline  = np.linspace(x.min() - 2, x.max() + 2, 100)
    ax.plot(xline, m * xline + b, "r--", linewidth=2,
            label=f"Régression  r={corr['pearson_r']}  p={corr['pearson_p']}")

    # Ligne d'alignement parfait
    lim = max(x.max(), y.max()) + 5
    ax.plot([0, lim], [0, lim], "k:", linewidth=1.2,
            alpha=0.5, label="Alignement parfait (45°)")

    ax.set_xlabel("Poids Fréquence Thématique (%)", fontsize=11)
    ax.set_ylabel("Poids Financier BIP (%)", fontsize=11)
    ax.set_title("Discours Budgétaire vs Réalité Financière\n"
                 f"Alignement aux Piliers SND30  —  R²={corr['pearson_r2']}%",
                 fontweight="bold")
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.4)
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Regplot sauvegardé → {path}")
    plt.show()


def _plot_dotplot_asymetrie(bilan: pd.DataFrame,
                             col_pilier: str,
                             save_fig: bool,
                             path: str):
    """Dot-plot : visualisation de l'asymétrie fréquence vs financier."""
    df_dot = bilan.sort_values("Poids_Financier_%")

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.hlines(df_dot[col_pilier],
              df_dot["Poids_Frequence_%"],
              df_dot["Poids_Financier_%"],
              color="grey", alpha=0.6, linewidth=2.5)

    ax.scatter(df_dot["Poids_Frequence_%"], df_dot[col_pilier],
               color="#3498DB", s=160, zorder=5,
               label="Poids Fréquence Thématique (%)")
    ax.scatter(df_dot["Poids_Financier_%"], df_dot[col_pilier],
               color="#E74C3C", s=160, zorder=5,
               label="Poids Financier BIP (%)")

    # Annotations des écarts
    for _, row in df_dot.iterrows():
        mid_x  = (row["Poids_Frequence_%"] + row["Poids_Financier_%"]) / 2
        symbol = "▲" if row["Ecart_Poids_%"] > 0 else "▼"
        color  = "#27AE60" if row["Ecart_Poids_%"] > 0 else "#C0392B"
        ax.text(mid_x, row[col_pilier],
                f"{symbol}{abs(row['Ecart_Poids_%']):.1f}%",
                ha="center", va="bottom", fontsize=9,
                fontweight="bold", color=color)

    ax.set_xlabel("Part relative (%)", fontsize=11)
    ax.set_title("Asymétrie : Intensité Discursive vs Effort Financier par Pilier SND30",
                 fontweight="bold")
    ax.legend(fontsize=10)
    ax.grid(axis="x", alpha=0.4)
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Dot-plot asymétrie sauvegardé → {path}")
    plt.show()


def _plot_double_axe(bilan: pd.DataFrame,
                     col_pilier: str,
                     save_fig: bool,
                     path: str):
    """Double axe : fréquence thématique (barres) vs montant BIP (ligne)."""
    fig, ax1 = plt.subplots(figsize=(11, 6))
    x_pos  = np.arange(len(bilan))
    colors = [COLORS_PILIERS.get(p, "#7F8C8D") for p in bilan[col_pilier]]

    bars = ax1.bar(x_pos, bilan["Frequence_Thematique"],
                   color=colors, edgecolor="black",
                   alpha=0.8, label="Fréquence thématique")
    ax1.set_ylabel("Fréquence thématique (nombre de projets)",
                   color="#2C3E50", fontsize=11)
    ax1.tick_params(axis="y", labelcolor="#2C3E50")
    ax1.set_xticks(x_pos)
    ax1.set_xticklabels(bilan[col_pilier], rotation=18, ha="right", fontsize=10)

    # Annotations barres
    for bar, val in zip(bars, bilan["Frequence_Thematique"]):
        ax1.text(bar.get_x() + bar.get_width() / 2,
                 bar.get_height() + 0.5,
                 str(int(val)), ha="center", fontsize=10, fontweight="bold")

    ax2 = ax1.twinx()
    ax2.plot(x_pos, bilan["Montant_Milliards"],
             "ro-", linewidth=2.5, markersize=10,
             label="Montant BIP (Mrds FCFA)", zorder=5)
    for i, val in enumerate(bilan["Montant_Milliards"]):
        ax2.text(i, val + 0.3, f"{val:.1f}", ha="center",
                 fontsize=9, color="red", fontweight="bold")
    ax2.set_ylabel("Montant total AE (Milliards FCFA)",
                   color="#C0392B", fontsize=11)
    ax2.tick_params(axis="y", labelcolor="#C0392B")

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2,
               loc="upper right", fontsize=10)
    ax1.set_title("Analyse Comparative : Visibilité Sémantique vs Masse Financière\n"
                  "par Pilier SND30", fontweight="bold")
    ax1.grid(axis="y", linestyle="--", alpha=0.4)
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Double axe sauvegardé → {path}")
    plt.show()


def _plot_evolution_annuelle(bilan_annuel: pd.DataFrame,
                              col_pilier:  str,
                              col_annee:   str,
                              save_fig:    bool,
                              path:        str):
    """Barres groupées : évolution du budget et de la fréquence par année."""
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))

    for ax, metric, label, title in [
        (axes[0], "Montant_Milliards",    "Montant (Mrds FCFA)",
         "Évolution du Budget BIP par Pilier (2024 vs 2025)"),
        (axes[1], "Poids_Frequence_%",    "Poids Fréquence (%)",
         "Évolution de l'Intensité Discursive par Pilier (2024 vs 2025)")
    ]:
        pivot = bilan_annuel.pivot(index=col_pilier,
                                    columns=col_annee,
                                    values=metric)
        x     = np.arange(len(pivot))
        w     = 0.35
        annees = sorted(bilan_annuel[col_annee].unique())
        cols_bar = ["#2E86C1", "#E74C3C"]

        for i, (annee, col_bar) in enumerate(zip(annees, cols_bar)):
            if annee in pivot.columns:
                rects = ax.bar(x + (i - 0.5) * w,
                               pivot[annee].fillna(0),
                               w, label=str(annee),
                               color=col_bar, edgecolor="black", alpha=0.85)
                for rect in rects:
                    h = rect.get_height()
                    if h > 0:
                        ax.text(rect.get_x() + rect.get_width() / 2,
                                h + 0.01 * pivot.values.max(),
                                f"{h:.1f}", ha="center",
                                fontsize=8, fontweight="bold")

        ax.set_xticks(x)
        ax.set_xticklabels(pivot.index, rotation=18, ha="right", fontsize=9)
        ax.set_ylabel(label, fontsize=10)
        ax.set_title(title, fontweight="bold")
        ax.legend(title="Année", fontsize=9)
        ax.grid(axis="y", alpha=0.4)

    plt.suptitle("Comparaison 2024 vs 2025 — Budget & Discours par Pilier SND30",
                 fontsize=13, fontweight="bold", y=1.02)
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Évolution annuelle sauvegardée → {path}")
    plt.show()


def _plot_tableau_bord(bilan: pd.DataFrame,
                        corr:  dict,
                        col_pilier: str,
                        save_fig: bool,
                        path: str):
    """Tableau de bord récapitulatif final avec corrélations."""
    fig, axes = plt.subplots(1, 2, figsize=(16, 5))

    # --- Tableau par pilier ---
    ax = axes[0]
    cols_affich = [col_pilier, "Frequence_Thematique",
                   "Montant_Milliards",
                   "Poids_Frequence_%", "Poids_Financier_%",
                   "Ecart_Poids_%", "Direction_Ecart"]
    col_labels  = ["Pilier", "Nb Projets", "Budget (Mrds)",
                   "Poids Fréq. %", "Poids Fin. %",
                   "Écart %", "Direction"]
    data = bilan[cols_affich].values.tolist()
    tbl  = ax.table(cellText=data, colLabels=col_labels,
                    loc="center", cellLoc="center")
    tbl.auto_set_font_size(False); tbl.set_fontsize(9); tbl.scale(1.2, 2.4)
    for j in range(len(col_labels)):
        tbl[(0, j)].set_facecolor("#2C3E50")
        tbl[(0, j)].set_text_props(color="white", fontweight="bold")
    for i, row in bilan.iterrows():
        color = "#ABEBC6" if row["Ecart_Poids_%"] > 0 else "#FADBD8"
        for j in range(len(col_labels)):
            tbl[(i + 1, j)].set_facecolor(color)
    ax.axis("off")
    ax.set_title("Tableau de Bord — BIP × Thématiques SND30",
                 fontweight="bold", pad=15)

    # --- Tableau corrélations ---
    ax2 = axes[1]
    corr_data = [
        ["Pearson r",       f"{corr['pearson_r']}"],
        ["R² (var. expl.)", f"{corr['pearson_r2']} %"],
        ["p-value Pearson", f"{corr['pearson_p']}"],
        ["Spearman ρ",      f"{corr['spearman_r']}"],
        ["p-value Spearman",f"{corr['spearman_p']}"],
        ["Force",           corr["force"]],
        ["Direction",       corr["direction"]],
        ["Significatif",    corr["sig"]]
    ]
    tbl2 = ax2.table(cellText=corr_data,
                     colLabels=["Indicateur", "Valeur"],
                     loc="center", cellLoc="center")
    tbl2.auto_set_font_size(False); tbl2.set_fontsize(11); tbl2.scale(1.5, 2.3)
    for j in range(2):
        tbl2[(0, j)].set_facecolor("#2C3E50")
        tbl2[(0, j)].set_text_props(color="white", fontweight="bold")
    color_sig = "#ABEBC6" if corr["sig"] == "SIGNIFICATIF" else "#FADBD8"
    for j in range(2):
        tbl2[(8, j)].set_facecolor(color_sig)
    ax2.axis("off")
    ax2.set_title("Résultats des Corrélations\n(Fréquence Thématique vs Poids Financier)",
                  fontweight="bold", pad=15)

    plt.suptitle(
        f"Corrélation Discours Budgétaire × BIP  |  "
        f"Pearson r={corr['pearson_r']}  Spearman ρ={corr['spearman_r']}  "
        f"({corr['sig']})",
        fontsize=12, fontweight="bold", y=1.02
    )
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Tableau de bord sauvegardé → {path}")
    plt.show()


def _plot_boxplot_distribution(df_total: pd.DataFrame,
                                col_pilier:  str,
                                col_montant: str,
                                save_fig:    bool,
                                path:        str):
    """Boxplot des montants AE par pilier (échelle log)."""
    fig, ax = plt.subplots(figsize=(11, 6))
    colors  = [COLORS_PILIERS.get(p, "#7F8C8D")
               for p in sorted(df_total[col_pilier].dropna().unique())]

    sns.boxplot(x=col_pilier, y=col_montant,
                data=df_total.dropna(subset=[col_pilier, col_montant]),
                palette=COLORS_PILIERS, ax=ax)
    ax.set_yscale("log")
    ax.set_title("Distribution des Crédits AE par Pilier SND30\n"
                 "(Échelle logarithmique)", fontweight="bold")
    ax.set_ylabel("Montant AE (Échelle Log)", fontsize=11)
    ax.set_xlabel("Pilier SND30", fontsize=11)
    ax.set_xticklabels(ax.get_xticklabels(), rotation=15, ha="right")
    ax.grid(axis="y", linestyle="--", alpha=0.5)
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Boxplot distribution sauvegardé → {path}")
    plt.show()


# ── Fonction principale exportée ──────────────────────────────────────────────
def run_correlation_bip(
    df_total:       pd.DataFrame,
    df_2024_classe: pd.DataFrame = None,
    df_2025_classe: pd.DataFrame = None,
    col_pilier:     str  = "Pilier_SND30",
    col_pilier_cls: str  = "pilier",
    col_texte:      str  = "Libellé",
    col_montant:    str  = "AE",
    col_annee:      str  = "Année",
    save_fig:       bool = True,
    fig_prefix:     str  = "fig4"
) -> dict:
    """
    Corrélation entre fréquences thématiques extraites et montants BIP.

    Paramètres
    ----------
    df_total        : DataFrame fusionné 2024+2025
                      colonnes : [col_pilier, col_texte, col_montant, col_annee]
    df_2024_classe  : optionnel — pour calculs complémentaires
    df_2025_classe  : optionnel — pour calculs complémentaires
    col_pilier      : colonne pilier dans df_total      (défaut : 'Pilier_SND30')
    col_pilier_cls  : colonne pilier dans df_*_classe   (défaut : 'pilier')
    col_texte       : colonne libellé dans df_total     (défaut : 'Libellé')
    col_montant     : colonne montant dans df_total     (défaut : 'AE')
    col_annee       : colonne année  dans df_total      (défaut : 'Année')
    save_fig        : sauvegarder les figures           (défaut : True)
    fig_prefix      : préfixe des noms de fichiers      (défaut : 'fig4')

    Retourne
    --------
    dict avec clés :
        bilan           : DataFrame tableau de bord par pilier
        bilan_annuel    : DataFrame tableau de bord par pilier × année
        correlations    : dict Pearson / Spearman
    """

    print("=" * 68)
    print("  SECTION 4 — CORRÉLATION THÉMATIQUES × MONTANTS BIP")
    print("=" * 68)

    # ── 1. Tableaux de bord ───────────────────────────────────────────────────
    print("\n  [1/4] Construction des tableaux de bord...")
    bilan        = _build_bilan(df_total, col_pilier, col_texte, col_montant)
    bilan_annuel = _build_bilan_annuel(df_total, col_pilier, col_texte,
                                        col_montant, col_annee)

    print("\n  Tableau de bord global :")
    print(bilan[[col_pilier, "Frequence_Thematique", "Montant_Milliards",
                  "Poids_Frequence_%", "Poids_Financier_%",
                  "Ecart_Poids_%", "Direction_Ecart"]].to_string(index=False))

    # ── 2. Corrélations ───────────────────────────────────────────────────────
    print("\n  [2/4] Calcul des corrélations...")
    corr = _calcul_correlations(bilan)

    print(f"\n  Pearson  r  = {corr['pearson_r']}   "
          f"(p={corr['pearson_p']},  R²={corr['pearson_r2']}%)")
    print(f"  Spearman ρ  = {corr['spearman_r']}  "
          f"(p={corr['spearman_p']})")
    print(f"\n  → Alignement {corr['force']} et {corr['direction']} "
          f"— {corr['sig']}")

    # ── 3. Graphiques ─────────────────────────────────────────────────────────
    print("\n  [3/4] Génération des figures...")

    _plot_regplot(
        bilan, corr, col_pilier,
        save_fig = save_fig,
        path     = f"{fig_prefix}_regplot.png"
    )
    _plot_dotplot_asymetrie(
        bilan, col_pilier,
        save_fig = save_fig,
        path     = f"{fig_prefix}_dotplot_asymetrie.png"
    )
    _plot_double_axe(
        bilan, col_pilier,
        save_fig = save_fig,
        path     = f"{fig_prefix}_double_axe.png"
    )
    _plot_evolution_annuelle(
        bilan_annuel, col_pilier, col_annee,
        save_fig = save_fig,
        path     = f"{fig_prefix}_evolution_annuelle.png"
    )
    _plot_boxplot_distribution(
        df_total, col_pilier, col_montant,
        save_fig = save_fig,
        path     = f"{fig_prefix}_boxplot_distribution.png"
    )

    # ── 4. Tableau de bord final ───────────────────────────────────────────────
    print("\n  [4/4] Tableau de bord final...")
    _plot_tableau_bord(
        bilan, corr, col_pilier,
        save_fig = save_fig,
        path     = f"{fig_prefix}_tableau_bord.png"
    )

    # ── 5. Résumé console ─────────────────────────────────────────────────────
    print("\n" + "-" * 68)
    print("  RÉSUMÉ SECTION 4 — CORRÉLATION BIP × THÉMATIQUES")
    print("-" * 68)
    print(f"  Pilier le mieux financé  : "
          f"{bilan.iloc[0][col_pilier]} "
          f"({bilan.iloc[0]['Montant_Milliards']:.1f} Mrds FCFA)")
    print(f"  Pilier le moins financé  : "
          f"{bilan.iloc[-1][col_pilier]} "
          f"({bilan.iloc[-1]['Montant_Milliards']:.1f} Mrds FCFA)")
    print(f"  Pearson  r  = {corr['pearson_r']}  (p={corr['pearson_p']})")
    print(f"  Spearman ρ  = {corr['spearman_r']}  (p={corr['spearman_p']})")
    print(f"  Alignement  : {corr['force']} — {corr['sig']}")
    print("-" * 68)
    print("  ✅ Section 4 terminée.\n")

    return {
        "bilan":        bilan,
        "bilan_annuel": bilan_annuel,
        "correlations": corr
    }
