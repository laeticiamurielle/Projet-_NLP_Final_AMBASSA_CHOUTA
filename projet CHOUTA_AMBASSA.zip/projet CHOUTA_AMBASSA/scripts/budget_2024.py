"""
Extraction des lignes budgétaires de la Loi des Finances 2023-2024 (Cameroun)
Source : LOI_DES_FINANCES_2023-2024.pdf
Colonnes extraites : N, COD, LIBELLE, OBJECTIF, INDICATEUR, AE, CP
"""

import pdfplumber
import pandas as pd
import re

pdf_path = r"C:\Users\Laeticia\Desktop\Loi_Finance\LOI DES FINANCES 2023-2024.pdf"

# Pages budgétaires : page 87 à 106 du PDF (index 0-based : 86 à 105)
BUDGET_START = 86   # inclus (page 87 du PDF)
BUDGET_END   = 107  # exclus (jusqu'a page 106)


# ─────────────────────────────────────────────────────────────
# UTILITAIRES
# ─────────────────────────────────────────────────────────────

def clean(s):
    """Nettoyage basique : espaces multiples, strip."""
    return re.sub(r'\s+', ' ', s or '').strip()


def clean_field(parts):
    """Assemble et nettoie les fragments d'une colonne."""
    text = clean(' '.join(parts))
    # Supprime les caracteres isoles (artefacts OCR)
    text = re.sub(r'(?<!\w)[a-z](?!\w)', '', text)
    return re.sub(r'\s+', ' ', text).strip()


def extract_ae_cp(line):
    """
    Extrait AE et CP depuis les tokens numeriques en fin de ligne.
    On travaille uniquement sur la partie droite (pos > 50) pour eviter
    de capturer N et COD.
    AE et CP etant souvent identiques, on cherche le meilleur decoupage
    en deux moities egales.
    """
    right = line[50:].rstrip() if len(line) > 50 else line.rstrip()
    tokens = []
    for tok in reversed(right.split()):
        if re.match(r'^\d+$', tok):
            tokens.insert(0, tok)
        else:
            break
    if not tokens:
        return '', ''

    digits = ''.join(tokens)
    n = len(digits)
    if n < 8:
        return '', digits

    half = n // 2
    best_split, best_diff = half, float('inf')
    for sp in range(max(4, half - 5), min(n - 4, half + 6)):
        a, b = digits[:sp], digits[sp:]
        if len(a) >= 4 and len(b) >= 4:
            try:
                diff = abs(int(a) - int(b)) / max(int(a), 1)
                if diff < best_diff:
                    best_diff, best_split = diff, sp
            except ValueError:
                pass
    return digits[:best_split], digits[best_split:]


def get_col_positions(lines):
    """
    Detecte les positions de colonnes depuis la ligne d'en-tete du tableau.
    Retourne (lib_start, obj_start, ind_start, ae_start).
    """
    for line in lines:
        if ('LIBELLE' in line or 'OBJECTIF' in line) and ('OBJECTIF' in line or 'INDICATEUR' in line):
            obj_pos = line.index('OBJECTIF')    if 'OBJECTIF'    in line else 34
            ind_pos = line.index('INDICATEUR')  if 'INDICATEUR'  in line else obj_pos + 14
            ae_pos  = line.index(' AE') + 1     if ' AE'         in line else ind_pos + 12
            return 18, obj_pos, ind_pos, ae_pos
    return 18, 34, 48, 58   # positions par defaut


def add_col_content(entry, line, lib_s, obj_s, ind_s, ae_s):
    """Decoupe une ligne selon les positions de colonnes et ajoute aux listes."""
    n = len(line)

    def seg(s, e):
        if n <= s:
            return ''
        chunk = line[s:min(e, n)]
        # Retire les chiffres en fin de segment (appartiennent a AE/CP)
        chunk = re.sub(r'[\d\s]+$', '', chunk)
        return chunk.strip()

    lib = seg(lib_s, obj_s)
    obj = seg(obj_s, ind_s)
    ind = seg(ind_s, ae_s)

    if lib and len(lib) > 1: entry['lib'].append(lib)
    if obj and len(obj) > 1: entry['obj'].append(obj)
    if ind and len(ind) > 1: entry['ind'].append(ind)


CHAPITRE_RE = re.compile(r'CHAPITRE\s+\d+\s*[-]', re.IGNORECASE)
SKIP_WORDS  = ['Unité', 'Programme']

# Mots indiquant du texte legal (avant les tableaux)
LEGAL_RE = re.compile(
    r'^\s*(notamment|emis|habilite|pour\s|de\s|Les\s|Au\s|En\s|'
    r'milliards|accord|exercice|prevoit|autorise|montant|valeur|plafond)',
    re.IGNORECASE
)


def is_skip(line):
    s = line.strip()
    if not s:
        return True
    if any(kw in s for kw in SKIP_WORDS):
        return True
    if CHAPITRE_RE.search(s):
        return True
    if 'LIBELLE' in s and 'OBJECTIF' in s:
        return True
    if re.match(r'^\s*[Ee]\s*$', s):
        return True
    if LEGAL_RE.match(s):
        return True
    return False


# ─────────────────────────────────────────────────────────────
# EXTRACTION PRINCIPALE
# ─────────────────────────────────────────────────────────────

all_entries = []

with pdfplumber.open(pdf_path) as pdf:
    for page_idx in range(BUDGET_START, min(BUDGET_END, len(pdf.pages))):
        page = pdf.pages[page_idx]
        text = page.extract_text(layout=True)
        if not text:
            continue

        lines = text.split('\n')

        # Positions de colonnes pour cette page
        lib_s, obj_s, ind_s, ae_s = get_col_positions(lines)

        current_entry = None
        pending_ae_cp = ('', '')   # AE/CP trouves AVANT la ligne N+COD

        for line in lines:
            stripped = line.strip()

            if is_skip(line):
                # Meme si on saute la ligne, on peut y trouver AE/CP
                # pour une entree dont N+COD arrive juste apres
                ae_pre, cp_pre = extract_ae_cp(line)
                if ae_pre or cp_pre:
                    pending_ae_cp = (ae_pre, cp_pre)
                continue

            # ── Detection ligne N+COD ─────────────────────────────
            n_val = cod_val = ''

            if len(line) >= 18:
                left = line[9:18]

                # Cas 1 : N et COD tous les deux presents
                m = re.match(r'\s*(\d{1,3})\s+(\d{3})\s*', left)
                if m and 1 <= int(m.group(1)) <= 300:
                    n_val, cod_val = m.group(1), m.group(2)

                # Cas 2 : COD seul (N absent)
                # Ex: "              169 PRÉSIDENTIELLE..." ou "              146 ET..."
                if not n_val:
                    m2 = re.match(r'^\s{3,}(\d{3})\s', left)
                    if m2 and re.search(r'\d{5,}', line[50:]):
                        cod_val = m2.group(1)

            is_entry = bool(cod_val)

            if is_entry:
                # Sauvegarde de l'entree precedente
                if current_entry:
                    all_entries.append(current_entry)

                ae, cp = extract_ae_cp(line)

                # Si AE/CP absents sur cette ligne, utilise ceux trouves juste avant
                if not ae and not cp:
                    ae, cp = pending_ae_cp
                pending_ae_cp = ('', '')

                current_entry = {
                    'N':       n_val,
                    'COD':     cod_val,
                    'lib':     [],
                    'obj':     [],
                    'ind':     [],
                    'ae':      ae,
                    'cp':      cp,
                    'page':    page_idx + 1,
                    'col_pos': (lib_s, obj_s, ind_s, ae_s),
                }
                add_col_content(current_entry, line, lib_s, obj_s, ind_s, ae_s)
                continue

            # ── Lignes de continuation ────────────────────────────
            ae, cp = extract_ae_cp(line)
            if current_entry is not None:
                if ae and not current_entry["ae"]:
                    current_entry["ae"] = ae
                elif ae and current_entry["ae"]:
                    # L entree courante a deja ses AE/CP : ces valeurs
                    # appartiennent probablement a l entree suivante
                    pending_ae_cp = (ae, cp)
                if cp and not current_entry["cp"]:
                    current_entry["cp"] = cp
                ls, os, is_, as_ = current_entry["col_pos"]
                add_col_content(current_entry, line, ls, os, is_, as_)
            else:
                # Avant la premiere entree : memorise AE/CP potentiels
                if ae or cp:
                    pending_ae_cp = (ae, cp)

        # Derniere entree de la page
        if current_entry:
            all_entries.append(current_entry)


# ─────────────────────────────────────────────────────────────
# CORRECTIONS : entrees sans N
# ─────────────────────────────────────────────────────────────

COD_TO_N = {'169': '2', '146': '146'}

for e in all_entries:
    if e['N'] == '' and e['COD'] in COD_TO_N:
        e['N'] = COD_TO_N[e['COD']]


# ─────────────────────────────────────────────────────────────
# CONSTRUCTION DU DATAFRAME
# ─────────────────────────────────────────────────────────────

rows = []
for e in all_entries:
    rows.append({
        'N':          e['N'],
        'COD':        e['COD'],
        'LIBELLE':    clean_field(e['lib']),
        'OBJECTIF':   clean_field(e['obj']),
        'INDICATEUR': clean_field(e['ind']),
        'AE':         e['ae'] if e['ae'] else None,
        'CP':         e['cp'] if e['cp'] else None,
        'PAGE_PDF':   e['page'],
    })

df = pd.DataFrame(rows)

# Convertit AE et CP en numerique (milliers FCFA)
df['AE'] = pd.to_numeric(df['AE'], errors='coerce')
df['CP'] = pd.to_numeric(df['CP'], errors='coerce')

# Tri par N numerique
df['N_num'] = pd.to_numeric(df['N'], errors='coerce')
df = df.sort_values('N_num').drop(columns='N_num').reset_index(drop=True)


# ─────────────────────────────────────────────────────────────
# RAPPORT DE QUALITE
# ─────────────────────────────────────────────────────────────

print("=" * 60)
print("RAPPORT D'EXTRACTION")
print("=" * 60)
print(f"Total lignes budgetaires extraites : {len(df)}")
print(f"  Avec N      : {df['N'].ne('').sum()}")
print(f"  Avec COD    : {df['COD'].ne('').sum()}")
print(f"  Avec AE     : {df['AE'].notna().sum()}")
print(f"  Avec CP     : {df['CP'].notna().sum()}")

missing = df[df['AE'].isna() | df['CP'].isna()]
if len(missing) > 0:
    print(f"\n  Lignes avec AE ou CP manquant :")
    print(missing[['N', 'COD', 'AE', 'CP', 'PAGE_PDF']].to_string())
else:
    print("\n  Aucune valeur AE/CP manquante")

print("\nRepartition par page PDF :")
print(df.groupby('PAGE_PDF').size().to_string())

# Verification d'entrees connues
print("\nVerification entrees cles :")
checks = {
    '1':   (21459760,  21459760),
    '2':   (7918493,   7918493),
    '3':   (25954747,  25954747),
    '17':  (8046995,   8046995),
    '92':  (1043000,   1043000),
    '102': (17142147,  17142147),
    '148': (3069863,   3069863),
    '173': (11962000,  11962000),
    '174': (3058000,   3058000),
    '175': (269668000, 269668000),
}
for n_str, (exp_ae, exp_cp) in checks.items():
    sub = df[df['N'] == n_str]
    if len(sub) == 0:
        print(f"  N={n_str}: NON TROUVE")
        continue
    r = sub.iloc[0]
    ok_ae = 'OK' if r['AE'] == exp_ae else f'ERREUR (got {r["AE"]})'
    ok_cp = 'OK' if r['CP'] == exp_cp else f'ERREUR (got {r["CP"]})'
    print(f"  N={n_str:>4} COD={r['COD']}: AE={ok_ae}  CP={ok_cp}")


# ─────────────────────────────────────────────────────────────
# SAUVEGARDE
# ... (Après la création du dataframe df) ...

# 1. Utiliser des 'r' devant les chemins pour éviter l'erreur Unicode
out_csv  = r"C:\Users\Laeticia\Desktop\CHOUTA_NLP_Finance\venv\lignes_budgetaires_2023_2024.csv"
out_xlsx = r"C:\Users\Laeticia\Desktop\CHOUTA_NLP_Finance\venv\lignes_budgetaires_2023_2024.xlsx"

# 2. On met les affichages et sauvegardes dans ce bloc spécial
if __name__ == "__main__":
    print("=" * 60)
    print("RAPPORT D'EXTRACTION")
    print("=" * 60)
    print(f"Total lignes budgetaires extraites : {len(df)}")
    # ... (gardez vos autres prints ici) ...
    
    # Sauvegarde des fichiers
    df.to_csv(out_csv,  index=False, encoding='utf-8-sig')
    df.to_excel(out_xlsx, index=False)
    print(f"\nFichiers sauvegardés.")
    print("=" * 60)