"""
=============================================================================
SECTION 1 : Divergence de Jensen-Shannon — Rupture Discursive 2024 → 2025
Projet NLP ISE3 - ISSEA Yaoundé 2025-2026
=============================================================================
Usage :
    from section1_jensen_shannon import run_jensen_shannon
    df_js = run_jensen_shannon(df_2024_classe, df_2025_classe)
=============================================================================
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.spatial.distance import jensenshannon


# ── Constantes ────────────────────────────────────────────────────────────────
PILIERS = [
    "Transformation structurelle",
    "Capital humain",
    "Gouvernance",
    "Développement régional"
]

SEUILS = {"modere": 0.15, "fort": 0.30}


# ── Fonctions internes ─────────────────────────────────────────────────────────
def _to_distribution(series: pd.Series, bins: int = 20) -> np.ndarray:
    """Convertit une série de scores en distribution de probabilité normalisée."""
    hist, _ = np.histogram(series.dropna(), bins=bins, range=(0.0, 1.0), density=True)
    hist = hist + 1e-10          # éviter les zéros (support de log)
    return hist / hist.sum()


def _couleur_barre(js_val: float) -> str:
    """Retourne une couleur selon l'intensité de la divergence."""
    if js_val >= SEUILS["fort"]:
        return "#C0392B"   # rouge  → rupture forte
    elif js_val >= SEUILS["modere"]:
        return "#F39C12"   # orange → rupture modérée
    else:
        return "#27AE60"   # vert   → stabilité


# ── Fonction principale exportée ───────────────────────────────────────────────
def run_jensen_shannon(
    df_2024_classe: pd.DataFrame,
    df_2025_classe: pd.DataFrame,
    col_pilier: str = "pilier",
    col_score: str  = "score_pilier",
    bins: int       = 20,
    save_fig: bool  = True,
    fig_path: str   = "fig1_jensen_shannon.png"
) -> pd.DataFrame:
    """
    Calcule la divergence de Jensen-Shannon entre les distributions
    de scores de confiance (zero-shot) 2024 et 2025 pour chaque pilier SND30.

    Paramètres
    ----------
    df_2024_classe : DataFrame issu de classify_df(df_2024)
    df_2025_classe : DataFrame issu de classify_df(df_2025)
    col_pilier     : nom de la colonne pilier  (défaut : 'pilier')
    col_score      : nom de la colonne score   (défaut : 'score_pilier')
    bins           : nombre de bins pour l'histogramme (défaut : 20)
    save_fig       : sauvegarder la figure (défaut : True)
    fig_path       : chemin de sauvegarde   (défaut : 'fig1_jensen_shannon.png')

    Retourne
    --------
    df_js : DataFrame avec colonnes [Pilier, JS_Divergence, n_2024, n_2025,
                                      Intensite, Interpretation]
    """

    # ── 1. Calcul des divergences ──────────────────────────────────────────────
    resultats = []
    for pilier in PILIERS:
        s24 = df_2024_classe.loc[df_2024_classe[col_pilier] == pilier, col_score].dropna()
        s25 = df_2025_classe.loc[df_2025_classe[col_pilier] == pilier, col_score].dropna()

        if len(s24) >= 2 and len(s25) >= 2:
            p   = _to_distribution(s24, bins)
            q   = _to_distribution(s25, bins)
            js  = float(jensenshannon(p, q))

            if js >= SEUILS["fort"]:
                intensite     = "Forte"
                interpretation = "Rupture discursive majeure"
            elif js >= SEUILS["modere"]:
                intensite     = "Modérée"
                interpretation = "Glissement sémantique partiel"
            else:
                intensite     = "Faible"
                interpretation = "Stabilité thématique"
        else:
            js             = np.nan
            intensite      = "N/A"
            interpretation = f"Effectif insuffisant (n2024={len(s24)}, n2025={len(s25)})"

        resultats.append({
            "Pilier":         pilier,
            "JS_Divergence":  round(js, 4) if not np.isnan(js) else np.nan,
            "n_2024":         len(s24),
            "n_2025":         len(s25),
            "Intensite":      intensite,
            "Interpretation": interpretation
        })

    df_js = pd.DataFrame(resultats).sort_values("JS_Divergence", ascending=False).reset_index(drop=True)

    # ── 2. Affichage console ───────────────────────────────────────────────────
    print("=" * 68)
    print("  SECTION 1 — DIVERGENCE DE JENSEN-SHANNON PAR PILIER SND30")
    print("=" * 68)
    print(f"\n  Seuils : modéré ≥ {SEUILS['modere']}  |  fort ≥ {SEUILS['fort']}\n")
    print(df_js.to_string(index=False))

    # ── 3. Graphique ───────────────────────────────────────────────────────────
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # --- 3a. Barres horizontales JS par pilier ---
    ax = axes[0]
    df_plot  = df_js.dropna(subset=["JS_Divergence"])
    couleurs = [_couleur_barre(v) for v in df_plot["JS_Divergence"]]

    bars = ax.barh(df_plot["Pilier"], df_plot["JS_Divergence"],
                   color=couleurs, edgecolor="black", linewidth=0.8, height=0.5)

    ax.axvline(SEUILS["modere"], color="#F39C12", linestyle="--",
               linewidth=1.8, label=f"Seuil modéré ({SEUILS['modere']})")
    ax.axvline(SEUILS["fort"],   color="#C0392B", linestyle="--",
               linewidth=1.8, label=f"Seuil fort ({SEUILS['fort']})")

    for bar, val in zip(bars, df_plot["JS_Divergence"]):
        ax.text(val + 0.005, bar.get_y() + bar.get_height() / 2,
                f"{val:.4f}", va="center", fontsize=10, fontweight="bold")

    ax.set_xlabel("Divergence de Jensen-Shannon  ∈ [0, 1]", fontsize=11)
    ax.set_title("Rupture Discursive entre LF 2024 et LF 2025\n(Jensen-Shannon par pilier SND30)",
                 fontweight="bold")
    ax.set_xlim(0, max(df_plot["JS_Divergence"].max() + 0.12, 0.45))
    ax.legend(fontsize=9)
    ax.grid(axis="x", alpha=0.35)

    # --- 3b. Tableau récapitulatif ---
    ax2 = axes[1]
    ax2.axis("off")

    table_data   = [[row["Pilier"], f"{row['JS_Divergence']:.4f}" if not np.isnan(row["JS_Divergence"]) else "N/A",
                     row["n_2024"], row["n_2025"], row["Intensite"]]
                    for _, row in df_js.iterrows()]
    col_labels   = ["Pilier", "JS", "n 2024", "n 2025", "Intensité"]

    tbl = ax2.table(cellText=table_data, colLabels=col_labels,
                    loc="center", cellLoc="center")
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(10)
    tbl.scale(1.3, 2.2)

    # En-tête
    for j in range(len(col_labels)):
        tbl[(0, j)].set_facecolor("#2C3E50")
        tbl[(0, j)].set_text_props(color="white", fontweight="bold")

    # Coloriser selon intensité
    couleur_map = {"Forte": "#FADBD8", "Modérée": "#FDEBD0", "Faible": "#ABEBC6", "N/A": "#F2F3F4"}
    for i, (_, row) in enumerate(df_js.iterrows()):
        c = couleur_map.get(row["Intensite"], "#FFFFFF")
        for j in range(len(col_labels)):
            tbl[(i + 1, j)].set_facecolor(c)

    ax2.set_title("Tableau récapitulatif — Jensen-Shannon",
                  fontweight="bold", pad=20)

    plt.suptitle(
        "Indice de Volatilité Législative : Analyse de la Rupture Discursive SND30",
        fontsize=13, fontweight="bold", y=1.02
    )
    plt.tight_layout()

    if save_fig:
        plt.savefig(fig_path, bbox_inches="tight", dpi=150)
        print(f"\n  ✅ Figure sauvegardée → {fig_path}")

    plt.show()
    return df_js
