"""
=============================================================================
SECTION 3 : Tests de Significativité sur l'Évolution des Thèmes SND30
Projet NLP ISE3 - ISSEA Yaoundé 2025-2026
=============================================================================
Usage :
    from section3_tests_significativite import run_tests_significativite
    resultats = run_tests_significativite(df_2024_classe, df_2025_classe, df_total)
=============================================================================
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from scipy.stats import mannwhitneyu, kruskal, chi2_contingency
import warnings
warnings.filterwarnings("ignore")


# ── Constantes ────────────────────────────────────────────────────────────────
PILIERS = [
    "Transformation structurelle",
    "Capital humain",
    "Gouvernance",
    "Développement régional"
]


# ── Fonctions internes ────────────────────────────────────────────────────────

def _test_mannwhitney(df_2024_classe: pd.DataFrame,
                      df_2025_classe: pd.DataFrame,
                      col_pilier: str,
                      col_score:  str) -> pd.DataFrame:
    """
    Test de Mann-Whitney U par pilier (scores 2024 vs 2025).
    H0 : les distributions sont identiques entre 2024 et 2025.
    """
    rows = []
    for pilier in PILIERS:
        s24 = df_2024_classe.loc[df_2024_classe[col_pilier] == pilier,
                                  col_score].dropna()
        s25 = df_2025_classe.loc[df_2025_classe[col_pilier] == pilier,
                                  col_score].dropna()

        if len(s24) >= 2 and len(s25) >= 2:
            stat, p = mannwhitneyu(s24, s25, alternative="two-sided")
            sig     = "✅ Oui" if p < 0.05 else "❌ Non"
            interp  = "Rupture détectée" if p < 0.05 else "Stabilité thématique"
            # Taille d'effet r = Z / sqrt(N)
            n       = len(s24) + len(s25)
            z       = (stat - (len(s24)*len(s25)/2)) / np.sqrt(
                       len(s24)*len(s25)*(n+1)/12)
            r_effet = abs(z) / np.sqrt(n)
        else:
            stat, p, sig, interp, r_effet = np.nan, np.nan, "N/A", "Effectif insuffisant", np.nan

        rows.append({
            "Pilier":              pilier,
            "n_2024":              len(s24),
            "n_2025":              len(s25),
            "Statistique U":       round(stat, 1) if not np.isnan(stat) else "N/A",
            "p-value":             round(p, 4)    if not np.isnan(p)    else "N/A",
            "Significatif α=0.05": sig,
            "Taille effet r":      round(r_effet, 3) if not np.isnan(r_effet) else "N/A",
            "Interprétation":      interp
        })
    return pd.DataFrame(rows)


def _test_kruskal(df_2024_classe: pd.DataFrame,
                  df_2025_classe: pd.DataFrame,
                  col_pilier: str,
                  col_score:  str) -> dict:
    """
    Test de Kruskal-Wallis global inter-piliers (combiné 2024+2025).
    H0 : les scores ne diffèrent pas entre piliers.
    """
    groupes = []
    noms    = []
    for pilier in PILIERS:
        s = pd.concat([
            df_2024_classe.loc[df_2024_classe[col_pilier] == pilier, col_score],
            df_2025_classe.loc[df_2025_classe[col_pilier] == pilier, col_score]
        ]).dropna()
        if len(s) >= 2:
            groupes.append(s.values)
            noms.append(pilier)

    if len(groupes) >= 2:
        stat, p = kruskal(*groupes)
        sig     = "✅ Oui" if p < 0.05 else "❌ Non"
        interp  = ("Les scores diffèrent significativement entre piliers."
                   if p < 0.05 else
                   "Pas de différence significative entre piliers.")
    else:
        stat, p, sig, interp = np.nan, np.nan, "N/A", "Données insuffisantes"

    return {"H": round(stat, 3) if not np.isnan(stat) else "N/A",
            "p": round(p, 4)    if not np.isnan(p)    else "N/A",
            "ddl": len(groupes) - 1,
            "Significatif": sig,
            "Interprétation": interp}


def _test_chi2(df_total: pd.DataFrame,
               col_annee:  str,
               col_pilier: str) -> dict:
    """
    Test du Chi² sur la table de contingence Année × Pilier.
    H0 : la distribution des piliers est indépendante de l'année.
    """
    contingence = pd.crosstab(df_total[col_annee], df_total[col_pilier])
    chi2, p, dof, expected = chi2_contingency(contingence)
    sig    = "✅ Oui" if p < 0.05 else "❌ Non"
    interp = ("Évolution thématique significative — rupture de discours détectée."
              if p < 0.05 else
              "Pas de changement significatif dans la distribution des piliers.")
    return {"chi2": round(chi2, 3), "p": round(p, 4), "ddl": dof,
            "Significatif": sig, "Interprétation": interp,
            "contingence": contingence, "expected": pd.DataFrame(
                expected, index=contingence.index, columns=contingence.columns)}


# ── Graphiques ────────────────────────────────────────────────────────────────

def _plot_violon_scores(df_2024_classe: pd.DataFrame,
                         df_2025_classe: pd.DataFrame,
                         col_pilier: str,
                         col_score:  str,
                         save_fig:   bool,
                         path:       str):
    """Violin plot des scores de confiance par pilier et par année."""
    frames = []
    for df, annee in [(df_2024_classe, "2024"), (df_2025_classe, "2025")]:
        tmp = df[[col_pilier, col_score]].copy().dropna()
        tmp["Année"] = annee
        tmp.rename(columns={col_pilier: "Pilier", col_score: "Score"}, inplace=True)
        frames.append(tmp)
    df_long = pd.concat(frames, ignore_index=True)

    fig, ax = plt.subplots(figsize=(13, 6))
    sns.violinplot(data=df_long, x="Pilier", y="Score", hue="Année",
                   split=True, inner="quart", palette={"2024": "#2E86C1", "2025": "#E74C3C"},
                   ax=ax)
    ax.set_title("Distribution des Scores de Confiance par Pilier SND30\n"
                 "(Violin plot — 2024 vs 2025)", fontweight="bold")
    ax.set_xlabel("Pilier SND30"); ax.set_ylabel("Score de confiance (zero-shot)")
    ax.set_xticklabels(ax.get_xticklabels(), rotation=15, ha="right")
    ax.grid(axis="y", alpha=0.4)
    ax.legend(title="Année")
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Figure violon sauvegardée → {path}")
    plt.show()


def _plot_tableau_mannwhitney(df_mw: pd.DataFrame,
                               save_fig: bool,
                               path:     str):
    """Tableau coloré des résultats Mann-Whitney U."""
    fig, ax = plt.subplots(figsize=(13, 4))
    ax.axis("off")

    cols_affich = ["Pilier", "n_2024", "n_2025",
                   "Statistique U", "p-value",
                   "Taille effet r", "Significatif α=0.05", "Interprétation"]
    data = df_mw[cols_affich].values.tolist()

    tbl = ax.table(cellText=data, colLabels=cols_affich,
                   loc="center", cellLoc="center")
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(9)
    tbl.scale(1.2, 2.3)

    # En-tête
    for j in range(len(cols_affich)):
        tbl[(0, j)].set_facecolor("#2C3E50")
        tbl[(0, j)].set_text_props(color="white", fontweight="bold")

    # Lignes colorées selon significativité
    for i, row in df_mw.iterrows():
        color = "#ABEBC6" if "✅" in str(row["Significatif α=0.05"]) else \
                "#FADBD8" if "❌" in str(row["Significatif α=0.05"]) else "#F2F3F4"
        for j in range(len(cols_affich)):
            tbl[(i + 1, j)].set_facecolor(color)

    ax.set_title("Test de Mann-Whitney U — Évolution des scores par pilier (2024 vs 2025)",
                 fontweight="bold", pad=20, fontsize=11)
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Tableau Mann-Whitney sauvegardé → {path}")
    plt.show()


def _plot_pvalues(df_mw: pd.DataFrame,
                  save_fig: bool,
                  path:     str):
    """Graphique des p-values par pilier avec seuil α=0.05."""
    df_plot = df_mw[df_mw["p-value"] != "N/A"].copy()
    df_plot["p-value"] = df_plot["p-value"].astype(float)
    df_plot = df_plot.sort_values("p-value")

    fig, ax = plt.subplots(figsize=(9, 5))
    colors  = ["#C0392B" if p < 0.05 else "#27AE60"
               for p in df_plot["p-value"]]
    bars    = ax.barh(df_plot["Pilier"], df_plot["p-value"],
                      color=colors, edgecolor="black", height=0.5)
    ax.axvline(0.05, color="black", linestyle="--",
               linewidth=2, label="Seuil α = 0.05")

    for bar, val in zip(bars, df_plot["p-value"]):
        ax.text(val + 0.002, bar.get_y() + bar.get_height() / 2,
                f"{val:.4f}", va="center", fontsize=10, fontweight="bold")

    rouge  = mpatches.Patch(color="#C0392B", label="Significatif (p < 0.05)")
    vert   = mpatches.Patch(color="#27AE60", label="Non significatif (p ≥ 0.05)")
    ax.legend(handles=[rouge, vert, ax.get_lines()[0]], fontsize=9)
    ax.set_xlabel("p-value (Mann-Whitney U)")
    ax.set_title("Significativité de l'Évolution Thématique par Pilier SND30",
                 fontweight="bold")
    ax.set_xlim(0, max(df_plot["p-value"].max() + 0.05, 0.15))
    ax.grid(axis="x", alpha=0.4)
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Figure p-values sauvegardée → {path}")
    plt.show()


def _plot_chi2_heatmap(res_chi2: dict,
                        save_fig: bool,
                        path:     str):
    """Heatmap de la table de contingence observée vs attendue."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Observé
    sns.heatmap(res_chi2["contingence"], annot=True, fmt="d",
                cmap="YlOrRd", ax=axes[0], linewidths=0.5)
    axes[0].set_title("Fréquences Observées\n(Année × Pilier SND30)",
                       fontweight="bold")
    axes[0].set_xlabel("Pilier"); axes[0].set_ylabel("Année")
    axes[0].set_xticklabels(axes[0].get_xticklabels(), rotation=20, ha="right")

    # Attendu sous H0
    sns.heatmap(res_chi2["expected"].round(1), annot=True, fmt=".1f",
                cmap="YlGnBu", ax=axes[1], linewidths=0.5)
    axes[1].set_title("Fréquences Attendues sous H₀\n(Indépendance Année × Pilier)",
                       fontweight="bold")
    axes[1].set_xlabel("Pilier"); axes[1].set_ylabel("Année")
    axes[1].set_xticklabels(axes[1].get_xticklabels(), rotation=20, ha="right")

    plt.suptitle(
        f"Test du Chi²  —  χ²={res_chi2['chi2']}  |  "
        f"ddl={res_chi2['ddl']}  |  p={res_chi2['p']}  |  {res_chi2['Significatif']}",
        fontsize=12, fontweight="bold", y=1.02
    )
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Heatmap Chi² sauvegardée → {path}")
    plt.show()


def _plot_tableau_synthese(df_mw: pd.DataFrame,
                            res_kw: dict,
                            res_chi2: dict,
                            save_fig: bool,
                            path:     str):
    """Tableau de synthèse des trois tests."""
    fig, axes = plt.subplots(1, 3, figsize=(17, 4))

    # --- Mann-Whitney résumé ---
    ax = axes[0]
    mw_data = [[row["Pilier"],
                str(row["p-value"]),
                row["Significatif α=0.05"]]
               for _, row in df_mw.iterrows()]
    tbl = ax.table(cellText=mw_data,
                   colLabels=["Pilier", "p-value", "Sig. ?"],
                   loc="center", cellLoc="center")
    tbl.auto_set_font_size(False); tbl.set_fontsize(10); tbl.scale(1.3, 2.4)
    for j in range(3):
        tbl[(0, j)].set_facecolor("#2C3E50")
        tbl[(0, j)].set_text_props(color="white", fontweight="bold")
    for i, row in df_mw.iterrows():
        c = "#ABEBC6" if "✅" in str(row["Significatif α=0.05"]) else \
            "#FADBD8" if "❌" in str(row["Significatif α=0.05"]) else "#F2F3F4"
        for j in range(3):
            tbl[(i+1, j)].set_facecolor(c)
    ax.axis("off")
    ax.set_title("Mann-Whitney U\n(par pilier)", fontweight="bold")

    # --- Kruskal-Wallis ---
    ax2 = axes[1]
    kw_data = [["H", str(res_kw["H"])],
               ["p-value", str(res_kw["p"])],
               ["ddl", str(res_kw["ddl"])],
               ["Significatif", res_kw["Significatif"]]]
    tbl2 = ax2.table(cellText=kw_data,
                     colLabels=["Statistique", "Valeur"],
                     loc="center", cellLoc="center")
    tbl2.auto_set_font_size(False); tbl2.set_fontsize(11); tbl2.scale(1.4, 2.6)
    for j in range(2):
        tbl2[(0, j)].set_facecolor("#2C3E50")
        tbl2[(0, j)].set_text_props(color="white", fontweight="bold")
    color_kw = "#ABEBC6" if "✅" in res_kw["Significatif"] else "#FADBD8"
    for j in range(2):
        tbl2[(4, j)].set_facecolor(color_kw)
    ax2.axis("off")
    ax2.set_title("Kruskal-Wallis\n(global inter-piliers)", fontweight="bold")

    # --- Chi² ---
    ax3 = axes[2]
    chi2_data = [["χ²",       str(res_chi2["chi2"])],
                 ["p-value",  str(res_chi2["p"])],
                 ["ddl",      str(res_chi2["ddl"])],
                 ["Significatif", res_chi2["Significatif"]]]
    tbl3 = ax3.table(cellText=chi2_data,
                     colLabels=["Statistique", "Valeur"],
                     loc="center", cellLoc="center")
    tbl3.auto_set_font_size(False); tbl3.set_fontsize(11); tbl3.scale(1.4, 2.6)
    for j in range(2):
        tbl3[(0, j)].set_facecolor("#2C3E50")
        tbl3[(0, j)].set_text_props(color="white", fontweight="bold")
    color_chi = "#ABEBC6" if "✅" in res_chi2["Significatif"] else "#FADBD8"
    for j in range(2):
        tbl3[(4, j)].set_facecolor(color_chi)
    ax3.axis("off")
    ax3.set_title("Chi²\n(structure Année × Pilier)", fontweight="bold")

    plt.suptitle("Synthèse des Tests de Significativité — Évolution Thématique SND30",
                 fontsize=13, fontweight="bold", y=1.02)
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Tableau synthèse sauvegardé → {path}")
    plt.show()


# ── Fonction principale exportée ──────────────────────────────────────────────
def run_tests_significativite(
    df_2024_classe: pd.DataFrame,
    df_2025_classe: pd.DataFrame,
    df_total:       pd.DataFrame,
    col_pilier:     str  = "pilier",
    col_score:      str  = "score_pilier",
    col_pilier_tot: str  = "Pilier_SND30",
    col_annee:      str  = "Année",
    save_fig:       bool = True,
    fig_prefix:     str  = "fig3"
) -> dict:
    """
    Tests de significativité sur l'évolution des thèmes SND30.

    Paramètres
    ----------
    df_2024_classe  : DataFrame classify_df(df_2024) — colonnes [col_pilier, col_score]
    df_2025_classe  : DataFrame classify_df(df_2025) — colonnes [col_pilier, col_score]
    df_total        : DataFrame fusionné 2024+2025   — colonnes [col_annee, col_pilier_tot]
    col_pilier      : colonne pilier dans df_2024/2025_classe  (défaut : 'pilier')
    col_score       : colonne score  dans df_2024/2025_classe  (défaut : 'score_pilier')
    col_pilier_tot  : colonne pilier dans df_total             (défaut : 'Pilier_SND30')
    col_annee       : colonne année  dans df_total             (défaut : 'Année')
    save_fig        : sauvegarder les figures                  (défaut : True)
    fig_prefix      : préfixe des noms de fichiers             (défaut : 'fig3')

    Retourne
    --------
    dict avec clés :
        df_mannwhitney  : résultats Mann-Whitney U par pilier
        kruskal_wallis  : dict résultats Kruskal-Wallis
        chi2            : dict résultats Chi²
    """

    print("=" * 68)
    print("  SECTION 3 — TESTS DE SIGNIFICATIVITÉ")
    print("=" * 68)

    # ── 1. Mann-Whitney U ─────────────────────────────────────────────────────
    print("\n  [1/3] Test de Mann-Whitney U (par pilier)...")
    df_mw = _test_mannwhitney(df_2024_classe, df_2025_classe, col_pilier, col_score)
    print(df_mw[["Pilier", "n_2024", "n_2025",
                  "p-value", "Significatif α=0.05", "Interprétation"]].to_string(index=False))

    # ── 2. Kruskal-Wallis ─────────────────────────────────────────────────────
    print("\n  [2/3] Test de Kruskal-Wallis (global inter-piliers)...")
    res_kw = _test_kruskal(df_2024_classe, df_2025_classe, col_pilier, col_score)
    print(f"  H = {res_kw['H']}  |  p = {res_kw['p']}  |  {res_kw['Interprétation']}")

    # ── 3. Chi² ───────────────────────────────────────────────────────────────
    print("\n  [3/3] Test du Chi² (structure Année × Pilier)...")
    res_chi2 = _test_chi2(df_total, col_annee, col_pilier_tot)
    print(f"  χ² = {res_chi2['chi2']}  |  ddl = {res_chi2['ddl']}  |  "
          f"p = {res_chi2['p']}  |  {res_chi2['Interprétation']}")

    # ── 4. Graphiques ─────────────────────────────────────────────────────────
    print("\n  Génération des figures...")

    _plot_violon_scores(
        df_2024_classe, df_2025_classe, col_pilier, col_score,
        save_fig = save_fig,
        path     = f"{fig_prefix}_violon_scores.png"
    )
    _plot_tableau_mannwhitney(
        df_mw,
        save_fig = save_fig,
        path     = f"{fig_prefix}_mannwhitney_tableau.png"
    )
    _plot_pvalues(
        df_mw,
        save_fig = save_fig,
        path     = f"{fig_prefix}_pvalues.png"
    )
    _plot_chi2_heatmap(
        res_chi2,
        save_fig = save_fig,
        path     = f"{fig_prefix}_chi2_heatmap.png"
    )
    _plot_tableau_synthese(
        df_mw, res_kw, res_chi2,
        save_fig = save_fig,
        path     = f"{fig_prefix}_synthese_tests.png"
    )

    # ── 5. Résumé console ─────────────────────────────────────────────────────
    print("\n" + "-" * 68)
    print("  RÉSUMÉ SECTION 3 — TESTS DE SIGNIFICATIVITÉ")
    print("-" * 68)
    n_sig = df_mw["Significatif α=0.05"].str.contains("✅", na=False).sum()
    print(f"  Mann-Whitney U  : {n_sig}/{len(df_mw)} piliers significatifs")
    print(f"  Kruskal-Wallis  : H={res_kw['H']}  p={res_kw['p']}  {res_kw['Significatif']}")
    print(f"  Chi²            : χ²={res_chi2['chi2']}  p={res_chi2['p']}  {res_chi2['Significatif']}")
    print("-" * 68)
    print("  ✅ Section 3 terminée.\n")

    return {
        "df_mannwhitney": df_mw,
        "kruskal_wallis": res_kw,
        "chi2":           res_chi2
    }
