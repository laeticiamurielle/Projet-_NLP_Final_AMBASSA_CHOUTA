"""
=============================================================================
SECTION 2 : Embeddings CamemBERT + HDBSCAN
Projet NLP ISE3 - ISSEA Yaoundé 2025-2026
=============================================================================
Usage :
    from section2_embeddings_hdbscan import run_embeddings_hdbscan
    resultats = run_embeddings_hdbscan(
                    matrice_semantique_2024,
                    matrice_semantique_2025,
                    articles_propres_2024,
                    articles_propres_2025)
=============================================================================
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from sklearn.decomposition import PCA
from sklearn.preprocessing import normalize
from sklearn.metrics import silhouette_score
from sklearn.cluster import KMeans
import hdbscan
import warnings
warnings.filterwarnings("ignore")


# ── Fonctions internes ────────────────────────────────────────────────────────

def _reduire_pca(X: np.ndarray, n_components: int, label: str) -> tuple:
    """Réduction dimensionnelle PCA."""
    pca   = PCA(n_components=n_components, random_state=42)
    X_red = pca.fit_transform(X)
    var   = pca.explained_variance_ratio_.sum() * 100
    print(f"  PCA {label} : {n_components} composantes → {var:.1f}% variance expliquée")
    return pca, X_red


def _run_hdbscan(X: np.ndarray,
                 min_cluster_size: int,
                 min_samples: int) -> tuple:
    """Lance HDBSCAN et retourne labels + statistiques."""
    clusterer  = hdbscan.HDBSCAN(
        min_cluster_size         = min_cluster_size,
        min_samples              = min_samples,
        metric                   = "euclidean",
        cluster_selection_method = "eom",
        prediction_data          = True
    )
    labels     = clusterer.fit_predict(X)
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    n_noise    = int(np.sum(labels == -1))
    return clusterer, labels, n_clusters, n_noise


def _silhouette_hdbscan(X: np.ndarray, labels: np.ndarray) -> float:
    """Calcule le score de silhouette en excluant le bruit (-1)."""
    mask = labels != -1
    if mask.sum() >= 2 and len(set(labels[mask])) >= 2:
        return float(silhouette_score(X[mask], labels[mask],
                                      sample_size=min(2000, mask.sum())))
    return np.nan


# ── Graphiques ────────────────────────────────────────────────────────────────

def _plot_hdbscan_2d(X_viz: np.ndarray,
                     labels: np.ndarray,
                     annees: list,
                     titre: str,
                     n_clusters: int,
                     n_noise: int,
                     save_fig: bool,
                     path: str):
    """Scatter 2D des clusters HDBSCAN colorés par cluster et par année."""
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))

    # --- Vue par cluster ---
    ax = axes[0]
    unique_lbl = sorted(set(labels))
    cmap       = plt.cm.get_cmap("tab20", len(unique_lbl))
    for i, lbl in enumerate(unique_lbl):
        mask      = labels == lbl
        label_str = "Bruit" if lbl == -1 else f"Cluster {lbl}"
        marker    = "x"     if lbl == -1 else "o"
       # Par :
    ax.scatter(X_viz[mask, 0], X_viz[mask, 1],
           color=cmap(i), label=label_str, # <-- Utilisez 'color' sans les crochets []
           alpha=0.6, s=25, marker=marker)
    ax.set_title(f"HDBSCAN — {n_clusters} clusters\n"
                 f"{n_noise} pts bruit ({100*n_noise/len(labels):.1f}%)",
                 fontweight="bold")
    ax.set_xlabel("PC1"); ax.set_ylabel("PC2")
    ax.legend(fontsize=8, ncol=2)
    ax.grid(True, alpha=0.3)

    # --- Vue par année ---
    ax2    = axes[1]
    colors = {"2024": "#2E86C1", "2025": "#E74C3C"}
    for annee, col in colors.items():
        mask = np.array(annees) == annee
        
        ax2.scatter(X_viz[mask, 0], X_viz[mask, 1],
                    c=col, label=f"LF {annee}", alpha=0.5, s=20)
    ax2.set_title("Séparation temporelle 2024 vs 2025\nProjection PCA 2D",
                  fontweight="bold")
    ax2.set_xlabel("PC1"); ax2.set_ylabel("PC2")
    ax2.legend(fontsize=10)
    ax2.grid(True, alpha=0.3)

    plt.suptitle(titre, fontsize=13, fontweight="bold", y=1.02)
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Figure sauvegardée → {path}")
    plt.show()


def _plot_dendrogram_condensed(clusterer,
                                save_fig: bool,
                                path: str):
    """Arbre de condensation HDBSCAN."""
    try:
        fig, ax = plt.subplots(figsize=(10, 5))
        clusterer.condensed_tree_.plot(
            axis                  = ax,
            select_clusters       = True,
            selection_palette     = plt.cm.tab10.colors,
            label_clusters        = True
        )
        ax.set_title("Arbre de Condensation HDBSCAN\n"
                     "(Visualisation de la hiérarchie des clusters)",
                     fontweight="bold")
        plt.tight_layout()
        if save_fig:
            plt.savefig(path, bbox_inches="tight", dpi=150)
            print(f"  ✅ Figure dendrogramme sauvegardée → {path}")
        plt.show()
    except Exception as e:
        print(f"  ⚠️  Dendrogramme non disponible : {e}")


def _plot_cluster_annee(labels: np.ndarray,
                         annees: list,
                         save_fig: bool,
                         path: str):
    """Histogramme empilé : répartition 2024 / 2025 par cluster."""
    df_tmp = pd.DataFrame({"Cluster": labels, "Année": annees})
    df_tmp = df_tmp[df_tmp["Cluster"] != -1]   # exclure bruit

    tab = pd.crosstab(df_tmp["Cluster"], df_tmp["Année"])
    tab.plot(kind="bar", figsize=(10, 5), color=["#2E86C1", "#E74C3C"],
             edgecolor="black")
    plt.title("Répartition des Articles 2024 / 2025 par Cluster HDBSCAN",
              fontweight="bold")
    plt.xlabel("Cluster"); plt.ylabel("Nombre d'articles")
    plt.xticks(rotation=0)
    plt.legend(title="Année"); plt.grid(axis="y", alpha=0.4)
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Figure cluster × année sauvegardée → {path}")
    plt.show()
    return tab


def _plot_similarite_intra_cluster(X: np.ndarray,
                                    labels: np.ndarray,
                                    save_fig: bool,
                                    path: str):
    """
    Boîtes à moustaches de la norme L2 intra-cluster
    (proxy de la cohésion sémantique).
    """
    from sklearn.metrics import pairwise_distances
    unique_lbl = [l for l in sorted(set(labels)) if l != -1]
    data, names = [], []
    for lbl in unique_lbl:
        mask = labels == lbl
        if mask.sum() >= 2:
            sub   = X[mask]
            dists = pairwise_distances(sub, metric="cosine").flatten()
            dists = dists[dists > 0]
            data.append(dists)
            names.append(f"C{lbl}\n(n={mask.sum()})")

    if not data:
        print("  ⚠️  Pas assez de données pour le boxplot intra-cluster.")
        return

    fig, ax = plt.subplots(figsize=(10, 5))
    bp = ax.boxplot(data, labels=names, patch_artist=True,
                    medianprops=dict(color="red", linewidth=2))
    colors = plt.cm.tab10(np.linspace(0, 1, len(data)))
    for patch, col in zip(bp["boxes"], colors):
        patch.set_facecolor(col); patch.set_alpha(0.7)
    ax.set_title("Cohésion Sémantique Intra-Cluster\n"
                 "(Distance cosinus — plus c'est bas, plus le cluster est cohérent)",
                 fontweight="bold")
    ax.set_ylabel("Distance cosinus"); ax.set_xlabel("Cluster")
    ax.grid(axis="y", alpha=0.4)
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Figure cohésion intra-cluster sauvegardée → {path}")
    plt.show()


def _plot_tableau_recap(df_recap: pd.DataFrame,
                         n_clusters: int,
                         n_noise: int,
                         sil: float,
                         save_fig: bool,
                         path: str):
    """Tableau récapitulatif des statistiques HDBSCAN."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 4))

    # --- Tableau stats globales ---
    ax = axes[0]
    global_data = [
        ["Embeddings",       "CamemBERT (768 dims)"],
        ["Réduction PCA",    "20 composantes"],
        ["Algorithme",       "HDBSCAN (eom)"],
        ["Clusters détectés", str(n_clusters)],
        ["Points bruit",     f"{n_noise}"],
        ["Score Silhouette", f"{sil:.4f}" if not np.isnan(sil) else "N/A"],
    ]
    tbl = ax.table(cellText=global_data,
                   colLabels=["Paramètre", "Valeur"],
                   loc="center", cellLoc="center")
    tbl.auto_set_font_size(False); tbl.set_fontsize(11)
    tbl.scale(1.4, 2.3)
    for j in range(2):
        tbl[(0, j)].set_facecolor("#2C3E50")
        tbl[(0, j)].set_text_props(color="white", fontweight="bold")
    ax.axis("off")
    ax.set_title("Paramètres & Résultats HDBSCAN", fontweight="bold")

    # --- Tableau par cluster ---
    ax2 = axes[1]
    ax2.table(
        cellText   = df_recap.values.tolist(),
        colLabels  = df_recap.columns.tolist(),
        loc        = "center",
        cellLoc    = "center"
    )
    tbl2 = ax2.tables[0]
    tbl2.auto_set_font_size(False); tbl2.set_fontsize(10)
    tbl2.scale(1.3, 2.1)
    for j in range(len(df_recap.columns)):
        tbl2[(0, j)].set_facecolor("#2C3E50")
        tbl2[(0, j)].set_text_props(color="white", fontweight="bold")
    ax2.axis("off")
    ax2.set_title("Statistiques par Cluster", fontweight="bold")

    plt.suptitle("Récapitulatif — Clustering HDBSCAN sur Embeddings CamemBERT",
                 fontsize=13, fontweight="bold", y=1.02)
    plt.tight_layout()
    if save_fig:
        plt.savefig(path, bbox_inches="tight", dpi=150)
        print(f"  ✅ Tableau récap sauvegardé → {path}")
    plt.show()


# ── Fonction principale exportée ──────────────────────────────────────────────
def run_embeddings_hdbscan(
    matrice_semantique_2024:  np.ndarray,
    matrice_semantique_2025:  np.ndarray,
    articles_propres_2024:    list = None,
    articles_propres_2025:    list = None,
    pca_components_hdb:       int  = 20,
    pca_components_viz:       int  = 2,
    hdbscan_min_cluster_size: int  = 5,
    hdbscan_min_samples:      int  = 3,
    save_fig:                 bool = True,
    fig_prefix:               str  = "fig2"
) -> dict:
    """
    Pipeline Embeddings CamemBERT + HDBSCAN.

    Paramètres
    ----------
    matrice_semantique_2024   : embeddings 2024  (n × 768)
    matrice_semantique_2025   : embeddings 2025  (m × 768)
    articles_propres_2024     : liste de dicts {'article': ..., 'texte_nettoye': ...}
    articles_propres_2025     : idem pour 2025
    pca_components_hdb        : dims PCA avant HDBSCAN       (défaut : 20)
    pca_components_viz        : dims PCA pour visualisation  (défaut : 2)
    hdbscan_min_cluster_size  : taille min cluster           (défaut : 5)
    hdbscan_min_samples       : min samples                  (défaut : 3)
    save_fig                  : sauvegarder les figures      (défaut : True)
    fig_prefix                : préfixe des noms de fichiers (défaut : 'fig2')

    Retourne
    --------
    dict avec clés :
        hdb_labels      : array labels HDBSCAN (−1 = bruit)
        n_clusters      : nombre de clusters détectés
        n_noise         : nombre de points bruit
        silhouette      : score de silhouette
        df_recap        : DataFrame stats par cluster
        tab_annee       : table cluster × année
        annees          : liste des labels d'année
        X_viz           : coordonnées PCA 2D pour réutilisation
    """

    print("=" * 68)
    print("  SECTION 2 — EMBEDDINGS CamemBERT + HDBSCAN")
    print("=" * 68)

    n24 = matrice_semantique_2024.shape[0]
    n25 = matrice_semantique_2025.shape[0]
    print(f"\n  Articles 2024 : {n24}  |  Articles 2025 : {n25}")

    # ── 1. Empilement et labels d'année ───────────────────────────────────────
    X_stack = np.vstack([matrice_semantique_2024, matrice_semantique_2025])
    n_total = X_stack.shape[0]          # longueur de référence
    annees  = ["2024"] * n24 + ["2025"] * n25

    # Labels textuels alignés strictement sur la taille des matrices
    if articles_propres_2024 is not None and articles_propres_2025 is not None:
        titres_24 = [a.get("article", f"Art2024_{i}")
                     for i, a in enumerate(articles_propres_2024)]
        titres_25 = [a.get("article", f"Art2025_{i}")
                     for i, a in enumerate(articles_propres_2025)]
        # Tronquer ou compléter pour correspondre exactement à n24 / n25
        titres_24 = (titres_24[:n24] if len(titres_24) >= n24
                     else titres_24 + [f"Art2024_{i}" for i in range(len(titres_24), n24)])
        titres_25 = (titres_25[:n25] if len(titres_25) >= n25
                     else titres_25 + [f"Art2025_{i}" for i in range(len(titres_25), n25)])
        titres = titres_24 + titres_25
    else:
        titres = [f"2024_{i}" for i in range(n24)] + [f"2025_{i}" for i in range(n25)]

    print(f"  Total vecteurs : {X_stack.shape[0]} × {X_stack.shape[1]}")

    # ── 2. PCA pour HDBSCAN ───────────────────────────────────────────────────
    print(f"\n  [1/4] Réduction PCA ({pca_components_hdb} composantes)...")
    _, X_hdb = _reduire_pca(X_stack, pca_components_hdb, "HDBSCAN")

    # ── 3. HDBSCAN ────────────────────────────────────────────────────────────
    print(f"\n  [2/4] HDBSCAN "
          f"(min_cluster_size={hdbscan_min_cluster_size}, "
          f"min_samples={hdbscan_min_samples})...")
    clusterer, hdb_labels, n_clusters, n_noise = _run_hdbscan(
        X_hdb, hdbscan_min_cluster_size, hdbscan_min_samples
    )
    sil = _silhouette_hdbscan(X_hdb, hdb_labels)

    print(f"  → Clusters : {n_clusters}  |  "
          f"Bruit : {n_noise} ({100*n_noise/len(hdb_labels):.1f}%)  |  "
          f"Silhouette : {sil:.4f}" if not np.isnan(sil) else
          f"  → Clusters : {n_clusters}  |  Bruit : {n_noise}  |  Silhouette : N/A")

    # ── 4. Statistiques par cluster ───────────────────────────────────────────
    # Alignement strict des longueurs
    n_total = len(hdb_labels)
    titres  = titres[:n_total]  if len(titres)  > n_total else titres  + [f"art_{i}" for i in range(len(titres),  n_total)]
    annees  = annees[:n_total]  if len(annees)  > n_total else annees  + ["????"]    * (n_total - len(annees))

    df_meta = pd.DataFrame({
        "Titre":   titres,
        "Année":   annees,
        "Cluster": hdb_labels
    })
    recap_rows = []
    for lbl in sorted(set(hdb_labels)):
        sub  = df_meta[df_meta["Cluster"] == lbl]
        nom  = "Bruit" if lbl == -1 else f"Cluster {lbl}"
        n24c = (sub["Année"] == "2024").sum()
        n25c = (sub["Année"] == "2025").sum()
        recap_rows.append({
            "Cluster":    nom,
            "Total":      len(sub),
            "n 2024":     n24c,
            "n 2025":     n25c,
            "% 2024":     f"{100*n24c/len(sub):.1f}%" if len(sub) > 0 else "N/A",
            "% 2025":     f"{100*n25c/len(sub):.1f}%" if len(sub) > 0 else "N/A"
        })
    df_recap = pd.DataFrame(recap_rows)
    print("\n  Statistiques par cluster :")
    print(df_recap.to_string(index=False))

    # ── 5. Visualisations ─────────────────────────────────────────────────────
    print("\n  [3/4] Génération des figures...")

    # PCA 2D pour visualisation
    _, X_viz = _reduire_pca(X_stack, pca_components_viz, "visualisation")

    _plot_hdbscan_2d(
        X_viz, hdb_labels, annees,
        titre      = "Clustering HDBSCAN sur Embeddings CamemBERT — LF 2024 & 2025",
        n_clusters = n_clusters,
        n_noise    = n_noise,
        save_fig   = save_fig,
        path       = f"{fig_prefix}_hdbscan_2d.png"
    )

    _plot_dendrogram_condensed(
        clusterer,
        save_fig = save_fig,
        path     = f"{fig_prefix}_hdbscan_dendro.png"
    )

    tab_annee = _plot_cluster_annee(
        hdb_labels, annees,
        save_fig = save_fig,
        path     = f"{fig_prefix}_hdbscan_cluster_annee.png"
    )

    _plot_similarite_intra_cluster(
        X_hdb, hdb_labels,
        save_fig = save_fig,
        path     = f"{fig_prefix}_hdbscan_cohesion.png"
    )

    # ── 6. Tableau récapitulatif ───────────────────────────────────────────────
    print("\n  [4/4] Tableau récapitulatif...")
    _plot_tableau_recap(
        df_recap, n_clusters, n_noise, sil,
        save_fig = save_fig,
        path     = f"{fig_prefix}_hdbscan_recap.png"
    )

    # ── 7. Résumé console ─────────────────────────────────────────────────────
    print("\n" + "-" * 68)
    print("  RÉSUMÉ SECTION 2 — EMBEDDINGS + HDBSCAN")
    print("-" * 68)
    print(f"  Embeddings CamemBERT  : {X_stack.shape[0]} vecteurs × {X_stack.shape[1]} dims")
    print(f"  PCA (HDBSCAN)         : {pca_components_hdb} composantes")
    print(f"  Clusters détectés     : {n_clusters}")
    print(f"  Points bruit          : {n_noise} ({100*n_noise/len(hdb_labels):.1f}%)")
    print(f"  Score Silhouette      : {sil:.4f}" if not np.isnan(sil) else
          f"  Score Silhouette      : N/A")
    print("-" * 68)
    print("  ✅ Section 2 terminée.\n")

    return {
        "hdb_labels":  hdb_labels,
        "n_clusters":  n_clusters,
        "n_noise":     n_noise,
        "silhouette":  sil,
        "df_recap":    df_recap,
        "tab_annee":   tab_annee,
        "annees":      annees,
        "X_viz":       X_viz,
        "df_meta":     df_meta
    }