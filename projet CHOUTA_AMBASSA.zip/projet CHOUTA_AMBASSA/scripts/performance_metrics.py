# performance_metrics.py

import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import ShuffleSplit, learning_curve
from sklearn.metrics import make_scorer, f1_score

f1_scorer = make_scorer(f1_score, average='macro', zero_division=0)

def plot_learning_curves_final(estimator, X, y):
    cv = ShuffleSplit(n_splits=10, test_size=0.2, random_state=42)
    train_sizes = np.linspace(30, len(X) - int(len(X)*0.2), 5).astype(int)

    train_sizes, train_scores, test_scores = learning_curve(
        estimator, X, y, train_sizes=train_sizes, cv=cv, scoring=f1_scorer, n_jobs=-1)

    if np.isnan(train_scores).all():
        train_sizes, train_scores, test_scores = learning_curve(
            estimator, X, y, train_sizes=train_sizes, cv=cv, scoring='accuracy')

    fig, ax = plt.subplots(figsize=(8, 6))  # ✅ Un seul graphique

    ax.plot(train_sizes, np.mean(train_scores, axis=1), 'o-', color="r", label="Entraînement")
    ax.plot(train_sizes, np.mean(test_scores, axis=1), 'o-', color="g", label="Validation")
    ax.fill_between(train_sizes,
                    np.mean(train_scores, axis=1) - np.std(train_scores, axis=1),
                    np.mean(train_scores, axis=1) + np.std(train_scores, axis=1),
                    alpha=0.1, color="r")
    ax.fill_between(train_sizes,
                    np.mean(test_scores, axis=1) - np.std(test_scores, axis=1),
                    np.mean(test_scores, axis=1) + np.std(test_scores, axis=1),
                    alpha=0.1, color="g")
    ax.set_title("F1-Score : Convergence du Modèle", fontweight='bold')
    ax.set_xlabel("Nombre d'articles de loi")
    ax.set_ylabel("F1-Score (macro)")
    ax.legend()
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()