
# -*- coding: utf-8 -*-

import pdfplumber
import pandas as pd
import re
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

PDF_PATH     = "C:\\Users\\Laeticia\\Desktop\\Loi_Finance\\LOI DES FINANCES 2024-2025.pdf"
BUDGET_START = 81   # index 0-based → page 82 du PDF
BUDGET_END   = 104  # exclusif     → jusqu'à page 104

# ─────────────────────────────────────────────────────────────
# UTILITAIRES
# ─────────────────────────────────────────────────────────────

def clean(s):
    return re.sub(r'\s+', ' ', s or '').strip()

def clean_field(parts):
    """Assemble les fragments d'une colonne et supprime les artefacts OCR."""
    text = clean(' '.join(parts))
    # Supprime les caractères isolés parasites
    text = re.sub(r'(?<!\w)[a-rt-z](?!\w)', '', text)
    text = re.sub(r'(?<!\w)[A-Z·](?!\w)', '', text)
    return re.sub(r'\s+', ' ', text).strip()

def extract_ae_cp(line):
    """
    Extrait AE et CP depuis les tokens numériques à droite de la ligne.
    Opère sur pos > 55 pour ne pas capturer N et COD.
    Cherche le meilleur découpage en deux valeurs proches (AE ≈ CP).
    Tolère les nombres séparés par des espaces ET les artefacts OCR.
    """
    right = line[55:].rstrip() if len(line) > 55 else line.rstrip()

    # ── Stratégie 1 : tokens purement numériques ─────────────
    tokens = []
    for tok in reversed(right.split()):
        if re.match(r'^\d+$', tok):
            tokens.insert(0, tok)
        else:
            break
    if tokens:
        digits = ''.join(tokens)
        n = len(digits)
        if n >= 8:
            half = n // 2
            best_split, best_diff = half, float('inf')
            for sp in range(max(4, half - 5), min(n - 4, half + 6)):
                a, b = digits[:sp], digits[sp:]
                if len(a) >= 4 and len(b) >= 4:
                    try:
                        diff = abs(int(a) - int(b)) / max(int(a), 1)
                        if diff < best_diff:
                            best_diff, best_split = diff, sp
                    except ValueError:
                        pass
            return digits[:best_split], digits[best_split:]
        if n >= 4:
            return '', digits

    # ── Stratégie 2 : tolérance OCR ──────────────────────────
    # Nettoie les caractères parasites (XX, CXXl, S·, '.J…)
    cleaned = re.sub(r'[^\d\s]', '', right)
    num_parts = [p for p in cleaned.split() if len(p) >= 1]
    if not num_parts:
        return '', ''
    all_digits = ''.join(num_parts)
    if len(all_digits) < 8:
        return '', all_digits if len(all_digits) >= 4 else ''
    n = len(all_digits)
    half = n // 2
    best_split, best_diff = half, float('inf')
    for sp in range(max(4, half - 5), min(n - 4, half + 6)):
        a, b = all_digits[:sp], all_digits[sp:]
        if len(a) >= 4 and len(b) >= 4:
            try:
                diff = abs(int(a) - int(b)) / max(int(a), 1)
                if diff < best_diff:
                    best_diff, best_split = diff, sp
            except ValueError:
                pass
    return all_digits[:best_split], all_digits[best_split:]

def has_ae_cp(line):
    """Vérifie si une ligne contient des valeurs AE/CP (même espacées)."""
    right = line[55:] if len(line) > 55 else line
    tokens = [t for t in right.split() if re.match(r'^\d+$', t)]
    total_digits = sum(len(t) for t in tokens)
    return total_digits >= 7  # AE ou CP minimum = 4 chiffres chacun

def get_col_positions(lines):
    """Détecte les positions de colonnes depuis la ligne d'en-tête."""
    for line in lines:
        if 'OBJECTIF' in line and 'INDICATEUR' in line and 'AE' in line:
            obj_pos = line.index('OBJECTIF')
            ind_pos = line.index('INDICATEUR')
            ae_pos  = line.index(' AE') + 1 if ' AE' in line else ind_pos + 13
            return 18, obj_pos, ind_pos, ae_pos
        if 'OBJECTIF' in line and 'INDICATEUR' in line:
            obj_pos = line.index('OBJECTIF')
            ind_pos = line.index('INDICATEUR')
            return 18, obj_pos, ind_pos, ind_pos + 13
    return 18, 37, 48, 61

def add_col_content(entry, line, lib_s, obj_s, ind_s, ae_s):
    """Découpe une ligne selon les positions colonnes et alimente les listes."""
    n = len(line)
    def seg(s, e):
        if n <= s: return ''
        chunk = line[s:min(e, n)]
        chunk = re.sub(r'[\d\s]+$', '', chunk)
        return chunk.strip()
    lib = seg(lib_s, obj_s)
    obj = seg(obj_s, ind_s)
    ind = seg(ind_s, ae_s)
    if lib and len(lib) > 1: entry['lib'].append(lib)
    if obj and len(obj) > 1: entry['obj'].append(obj)
    if ind and len(ind) > 1: entry['ind'].append(ind)

# ─────────────────────────────────────────────────────────────
# RÈGLES DE SAUT DE LIGNE
# ─────────────────────────────────────────────────────────────

CHAPITRE_RE   = re.compile(r'CHAPITRE\s+(\d+|PREMIER)\s*[-–.]', re.IGNORECASE)
LEGAL_RE      = re.compile(
    r'^\s*(notamment|milliards|accord|exercice|prévoit|autorise|montant|valeur|'
    r'plafond|comme\s|Article\s|ARTICLE\s|TITRE\s|MOYENS\s|CREDIT|DEUXIÈME|'
    r'DISPOSITIONS|programme\s)', re.IGNORECASE
)

def is_chapitre(line):
    return bool(CHAPITRE_RE.search(line.strip()))

def is_skip(line):
    s = line.strip()
    if not s: return True
    if is_chapitre(line): return True
    if any(kw in s for kw in ['Unité', 'PROGRAMME', 'Programme', 'Milliers']): return True
    if 'LIBELLE' in s and ('OBJECTIF' in s or 'CODE' in s): return True
    if 'OBJECTIF' in s and 'INDICATEUR' in s and 'AE' in s: return True
    if LEGAL_RE.match(s): return True
    if re.match(r'^\s*[\da-zA-Z·]\s*$', s): return True
    return False

# ─────────────────────────────────────────────────────────────
# EXTRACTION PRINCIPALE
# ─────────────────────────────────────────────────────────────

all_entries = []

with pdfplumber.open(PDF_PATH) as pdf:
    for page_idx in range(BUDGET_START, min(BUDGET_END, len(pdf.pages))):
        page  = pdf.pages[page_idx]
        text  = page.extract_text(layout=True)
        if not text: continue

        lines                         = text.split('\n')
        lib_s, obj_s, ind_s, ae_s     = get_col_positions(lines)
        current_entry                 = None
        pending_ae_cp                 = ('', '')

        for line in lines:
            # ── Ligne CHAPITRE : on la saute ET on réinitialise pending ──
            if is_chapitre(line):
                pending_ae_cp = ('', '')  # reset : valeurs du CHAPITRE ≠ valeurs de l'entrée suivante
                continue

            # ── Autres lignes à ignorer ───────────────────────────────────
            if is_skip(line):
                # On mémorise tout de même des AE/CP potentiels
                # SEULEMENT si ces valeurs semblent liées à une entrée budget
                # (pas à un titre ou une ligne de texte légal)
                ae_pre, cp_pre = extract_ae_cp(line)
                if ae_pre or cp_pre:
                    pending_ae_cp = (ae_pre, cp_pre)
                continue

            # ── Détection ligne N+COD ─────────────────────────────────────
            n_val = cod_val = ''

            if len(line) >= 18:
                left = line[9:23]

                # Cas 1 : N et COD présents   ex: "  1 168 ..."  "  21 050 ..."
                m = re.match(r'\s*(\d{1,3})\s+(\d{3})\s', left)
                if m and 1 <= int(m.group(1)) <= 300:
                    n_val, cod_val = m.group(1), m.group(2)

                # Cas 2 : N avec bruit OCR   ex: "  108w 137 ..."
                if not n_val:
                    m2 = re.match(r'\s*(\d{1,3})[a-zA-Z]\s+(\d{3})\s', left)
                    if m2 and 1 <= int(m2.group(1)) <= 300:
                        n_val, cod_val = m2.group(1), m2.group(2)

                # Cas 3 : COD seul sans N   ex: "    170 PRESIDENCE ..."
                # Condition : suffisamment de chiffres à droite (pos > 55)
                if not n_val:
                    m3 = re.match(r'^\s{3,5}(\d{3})\s', left)
                    if m3 and has_ae_cp(line):
                        cod_val = m3.group(1)

            is_entry = bool(cod_val)

            if is_entry:
                if current_entry:
                    all_entries.append(current_entry)

                ae, cp = extract_ae_cp(line)
                # Utilise les AE/CP mémorisés si non trouvés sur la ligne
                if not ae and not cp:
                    ae, cp = pending_ae_cp
                pending_ae_cp = ('', '')

                current_entry = {
                    'N':       n_val,
                    'COD':     cod_val,
                    'lib':     [],
                    'obj':     [],
                    'ind':     [],
                    'ae':      ae,
                    'cp':      cp,
                    'page':    page_idx + 1,
                    'col_pos': (lib_s, obj_s, ind_s, ae_s),
                }
                add_col_content(current_entry, line, lib_s, obj_s, ind_s, ae_s)
                continue

            # ── Lignes de continuation ────────────────────────────────────
            ae, cp = extract_ae_cp(line)
            if current_entry is not None:
                if ae and not current_entry['ae']:
                    current_entry['ae'] = ae
                elif ae and current_entry['ae']:
                    # Entrée déjà complète : ces valeurs appartiennent à la suivante
                    pending_ae_cp = (ae, cp)
                if cp and not current_entry['cp']:
                    current_entry['cp'] = cp
                ls, os, is_, as_ = current_entry['col_pos']
                add_col_content(current_entry, line, ls, os, is_, as_)
            else:
                if ae or cp:
                    pending_ae_cp = (ae, cp)

        if current_entry:
            all_entries.append(current_entry)

# ─────────────────────────────────────────────────────────────
# CORRECTIONS POST-EXTRACTION
# ─────────────────────────────────────────────────────────────

# COD→N pour les entrées où N est absent de la ligne (OCR)
COD_TO_N = {'170': '3'}

for e in all_entries:
    if e['N'] == '' and e['COD'] in COD_TO_N:
        e['N'] = COD_TO_N[e['COD']]
    # Si AE absent mais CP présent → AE = CP (OCR corrompu)
    if not e['ae'] and e['cp']:
        e['ae'] = e['cp']
    # Symétrie inverse
    if not e['cp'] and e['ae']:
        e['cp'] = e['ae']

# ─────────────────────────────────────────────────────────────
# DATAFRAME
# ─────────────────────────────────────────────────────────────

rows = []
for e in all_entries:
    rows.append({
        'N':          e['N'],
        'COD':        e['COD'],
        'LIBELLE':    clean_field(e['lib']),
        'OBJECTIF':   clean_field(e['obj']),
        'INDICATEUR': clean_field(e['ind']),
        'AE':         e['ae'] if e['ae'] else None,
        'CP':         e['cp'] if e['cp'] else None,
        'PAGE_PDF':   e['page'],
    })

df = pd.DataFrame(rows)
df['AE'] = pd.to_numeric(df['AE'], errors='coerce')
df['CP'] = pd.to_numeric(df['CP'], errors='coerce')
df['_N_num'] = pd.to_numeric(df['N'], errors='coerce')
df = df.sort_values('_N_num').drop(columns='_N_num').reset_index(drop=True)

# ─────────────────────────────────────────────────────────────
# RAPPORT DE QUALITÉ
# ─────────────────────────────────────────────────────────────

print("=" * 65)
print("  RAPPORT D'EXTRACTION — LOI DES FINANCES 2024-2025")
print("=" * 65)
print(f"  Total lignes budgétaires  : {len(df)}")
print(f"  Avec N°                   : {df['N'].ne('').sum()}")
print(f"  Avec COD                  : {df['COD'].ne('').sum()}")
print(f"  Avec AE                   : {df['AE'].notna().sum()}")
print(f"  Avec CP                   : {df['CP'].notna().sum()}")

missing = df[df['AE'].isna() | df['CP'].isna()]
if len(missing):
    print(f"\n  Lignes avec AE ou CP manquant ({len(missing)}) :")
    print(missing[['N', 'COD', 'AE', 'CP', 'PAGE_PDF']].to_string())
else:
    print("\n  Aucune valeur AE/CP manquante")

print("\n  Répartition par page PDF :")
dist = df.groupby('PAGE_PDF').size().reset_index(name='nb')
for _, row in dist.iterrows():
    print(f"    Page {int(row.PAGE_PDF):3d} → {int(row.nb)} lignes")
print("=" * 65)

# ─────────────────────────────────────────────────────────────
# SAUVEGARDE CSV + XLSX
# ─────────────────────────────────────────────────────────────

out_csv  = r"C:\Users\Laeticia\Desktop\CHOUTA_NLP_Finance\venv\lignes_budgetaires_2024_2025.csv"
out_xlsx = r"C:\Users\Laeticia\Desktop\CHOUTA_NLP_Finance\venv\lignes_budgetaires_2024_2025.xlsx"

df.to_csv(out_csv, index=False, encoding='utf-8-sig')

with pd.ExcelWriter(out_xlsx, engine='openpyxl') as writer:
    df.to_excel(writer, sheet_name='Lignes_budgetaires', index=False)
    ws = writer.sheets['Lignes_budgetaires']

    # ── En-tête ──────────────────────────────────────────────
    hdr_fill = PatternFill('solid', fgColor='1F4E79')
    hdr_font = Font(bold=True, color='FFFFFF', size=10)
    for cell in ws[1]:
        cell.fill      = hdr_fill
        cell.font      = hdr_font
        cell.alignment = Alignment(horizontal='center', vertical='center',
                                   wrap_text=True)
    ws.row_dimensions[1].height = 32

    # ── Largeurs de colonnes ──────────────────────────────────
    widths = {'N': 6, 'COD': 7, 'LIBELLE': 42, 'OBJECTIF': 36,
              'INDICATEUR': 36, 'AE': 18, 'CP': 18, 'PAGE_PDF': 9}
    for col_name, w in widths.items():
        if col_name in df.columns:
            col_idx = df.columns.get_loc(col_name) + 1
            ws.column_dimensions[get_column_letter(col_idx)].width = w

    # ── Alternance de couleurs sur les lignes ─────────────────
    fill_e = PatternFill('solid', fgColor='DCE6F1')
    fill_o = PatternFill('solid', fgColor='FFFFFF')
    for r_idx, row in enumerate(ws.iter_rows(min_row=2, max_row=ws.max_row), 2):
        fill = fill_e if r_idx % 2 == 0 else fill_o
        for cell in row:
            cell.fill = fill
            if isinstance(cell.value, (int, float)):
                cell.number_format = '#,##0'
                cell.alignment     = Alignment(horizontal='right',
                                               vertical='top')
            else:
                cell.alignment = Alignment(wrap_text=True, vertical='top')

    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions

print(f"\n  Fichiers sauvegardés :")
print(f"    {out_csv}")
print(f"    {out_xlsx}")
# 2. On met les affichages et sauvegardes dans ce bloc spécial
if __name__ == "__main__":
    print("=" * 60)
    print("RAPPORT D'EXTRACTION")
    print("=" * 60)
    print(f"Total lignes budgetaires extraites : {len(df)}")
    # ... (gardez vos autres prints ici) ...
    
    # Sauvegarde des fichiers
    df.to_csv(out_csv,  index=False, encoding='utf-8-sig')
    df.to_excel(out_xlsx, index=False)
    print(f"\nFichiers sauvegardés.")
    print("=" * 60)